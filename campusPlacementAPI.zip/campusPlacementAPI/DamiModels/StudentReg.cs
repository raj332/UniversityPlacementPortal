﻿using MessagePack;
using System.ComponentModel.DataAnnotations;
using KeyAttribute = System.ComponentModel.DataAnnotations.KeyAttribute;

namespace campusPlacementAPI.DamiModels
{
    public class StudentReg
    {
        [Key]
        public long Spid { get; set; }
        public string StudentName { get; set; } = null!;
        public int CourseId { get; set; }
        public long ContactNo { get; set; }
        public string Email { get; set; } = null!;
        public string Password { get; set; } = null!;
        public string Photo { get; set; } = null!;
    }
}
