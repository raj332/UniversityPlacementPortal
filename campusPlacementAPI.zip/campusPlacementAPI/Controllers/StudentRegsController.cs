﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.DamiModels;
using campusPlacementAPI.Models;
using System.IO;
using Microsoft.AspNetCore.Mvc.Razor.Infrastructure;
using System.Text.Json.Nodes;
using Microsoft.IdentityModel.Tokens;
using static campusPlacementAPI.Controllers.TokenManager;
using NuGet.ContentModel;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentRegsController : ControllerBase  
    {
        private readonly CampusManagementDBContext _context;

       
        public StudentRegsController(CampusManagementDBContext context)
        {
            _context = context;
        }
        // to get all student data 
        // GET: api/StudentRegs
        [HttpGet]
        public async Task<ActionResult<Object>> GetStudentReg() 
        {
            try
            {
               
                    // var a = _context.StudentMasterTbs .Select (*).Union (_context.PhotoMasterTbs .Select (x=>x)).ToList ();
                      var a = (from stu in _context.StudentMasterTbs 
                               join d in _context.PhotoMasterTbs on stu.Spid equals d.Spid
                               join c in _context.CourseMasterTbs on stu.CourseId equals c.CourseId
                               select new { stu.Spid,stu.StudentName,c.CourseName,stu.ContactNo,stu.Email,stu.IsInPlacementDrive,d.Photo} ).ToList() ;
                    return a ;
              

            } catch (Exception e)
            {
                return e;
            }
   
        }

        [HttpGet ("studentdetail/{id}")]
        public object GetStudentAllDetails(int id )
        {
            try
            {
                
                var temp = _context.PlacedStudentTbs.Where(x => x.Spid == id).FirstOrDefault();
                if ( temp != null)
                {
                  var   a = (from stu in _context.StudentMasterTbs
                             join b in _context.PlacedStudentTbs on stu.Spid equals b.Spid
                             join e in _context.CompanyMasterTbs on b.CompanyId equals e.CompanyId
                             join c in _context.JobProfileMasterTbs on stu.Spid equals c.Spid

                             where stu.Spid == id
                             select new { b.Ctc, b.Stipend, b.Year, e.Name, c.WebsiteLink, c.ResumeLink, c.LinkedinLink }
                   ).FirstOrDefault();
                    return a;
                }
                else
                {
                   var   a = _context.JobProfileMasterTbs.Where(x => x.Spid == id).FirstOrDefault();
                    return a;
                }


              
               
            }
            catch (Exception e)
            {
                return e;
            }

        }
        [HttpGet("changeIsInPlacement/{id}")]
        public object changeIsInPlacement(int id)
        {
            try
            {

                var temp = _context.StudentMasterTbs.Where(x => x.Spid == id).FirstOrDefault();
                if (temp.IsInPlacementDrive)
                {
                    temp.IsInPlacementDrive = false;
                    _context.SaveChanges();
                    return new JsonResult(new { success = true });
                }
                else
                {
                    temp.IsInPlacementDrive = true;
                    _context.SaveChanges();
                    return new JsonResult(new { success = true });
                }

            }
            catch (Exception e)
            {
                return e;
            }

        }

        // to get student detail 
        // GET: api/StudentRegs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<object>> GetStudentReg(long id)
        {
            try
            {
                Request.Headers.TryGetValue("Authorization", out var token);
                if (!token.IsNullOrEmpty())
                {
                      if(id==Convert.ToInt64(ValidateToken(token)))
                    {
                        var a = (from stu in _context.StudentMasterTbs
                                 join d in _context.PhotoMasterTbs on stu.Spid equals d.Spid
                                 join c in _context.CourseMasterTbs on stu.CourseId equals c.CourseId
                                 join f in _context.StudentLoginMasterTbs on stu.Spid equals f.Spid
                                 join e in _context.DepartmentMasterTbs on c.DepartmentId equals e.DepartmentId
                                 where stu.Spid == id
                                 select new { stu.Spid, stu.StudentName, c.CourseName, f.Password, stu.CourseId, stu.IsInPlacementDrive, e.DepartmentName, stu.ContactNo, stu.Email, d.Photo }).FirstOrDefault();

                        return a;
                    }else
                    {
                        return new JsonResult(new { error = "tokenExpired" });
                    }

                }
                else
                {
                    return new JsonResult(new { error = "noToken" });
                }
            }catch( Exception e)
            {
                return e;
            }


           
        }

       
        // PUT: api/StudentRegs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut()]
        public async Task<ActionResult<Object>> PutStudentReg( StudentReg input)
        {

            try
            {
                var temp = _context.StudentMasterTbs.Where(x => x.Spid == input.Spid).SingleOrDefault();
                temp.StudentName = input.StudentName;
                temp.CourseId = input.CourseId;
                temp.Email = input.Email;
                temp.ContactNo = input.ContactNo;
                var temp2 = _context.PhotoMasterTbs.Where(x => x.Spid == input.Spid).SingleOrDefault();
                temp2.Photo = input.Photo;
                var temp3 = _context.StudentLoginMasterTbs.Where(x => x.Spid == input.Spid).SingleOrDefault();
                temp3.Password = input.Password;
                await _context.SaveChangesAsync();
                return new JsonResult(new { success = true});
            }
            catch (Exception)
            {
                if (!StudentRegExists(input.Spid))
                {
                    return new JsonResult(new { error = "No user found" });
                }
                else
                {
                    return new JsonResult(new { error =" Technical Issue !" });
                }
            }

            
        }

        // POST: api/StudentRegs
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<JsonObject>> PostStudentReg(StudentReg studentReg)
        {
            try
            {
                var tmp = _context.StudentMasterTbs.Where(x => x.Spid == studentReg.Spid);
                if (tmp != null)
                {
                    return new JsonResult(new { success = false, error = "Spid is already registered !" });
                }else
                {
                    _context.StudentMasterTbs.Add(new StudentMasterTb { Spid = studentReg.Spid, ContactNo = studentReg.ContactNo, CourseId = studentReg.CourseId, IsInPlacementDrive = true, Email = studentReg.Email, StudentName = studentReg.StudentName });
                    _context.StudentLoginMasterTbs.Add(new StudentLoginMasterTb { Spid = studentReg.Spid, Password = studentReg.Password });
                    _context.PhotoMasterTbs.Add(new PhotoMasterTb { Photo = studentReg.Photo, Spid = studentReg.Spid });
                    await _context.SaveChangesAsync();
                }
                   
                
              
            }catch(Exception e)
            {
                return new JsonResult( new { success=false ,error = e });
            }
            

            return new JsonResult( new { success = true});
        }
/*
        // DELETE: api/StudentRegs/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudentReg(long id)
        {
            var studentReg = await _context.StudentReg.FindAsync(id);
            if (studentReg == null)
            {
                return NotFound();
            }

            _context.StudentReg.Remove(studentReg);
            await _context.SaveChangesAsync();

            return NoContent();
        }
*/
        private bool StudentRegExists(long id)
        {
            return _context.StudentMasterTbs.Any(e => e.Spid == id);
        }
    }
}
