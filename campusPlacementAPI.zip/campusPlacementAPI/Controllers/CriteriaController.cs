﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CriteriaController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public CriteriaController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/Criteria
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CriteriaMasterTb>>> GetCriteriaMasterTbs()
        {
            return await _context.CriteriaMasterTbs.ToListAsync();
        }

        // GET: api/Criteria/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CriteriaMasterTb>> GetCriteriaMasterTb(int id)
        {
            var criteriaMasterTb = await _context.CriteriaMasterTbs.FindAsync(id);

            if (criteriaMasterTb == null)
            {
                return NotFound();
            }

            return criteriaMasterTb;
        }

      /*  // PUT: api/Criteria/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCriteriaMasterTb(int id, CriteriaMasterTb criteriaMasterTb)
        {
            if (id != criteriaMasterTb.CriteriaId)
            {
                return BadRequest();
            }

            _context.Entry(criteriaMasterTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CriteriaMasterTbExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Criteria
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<CriteriaMasterTb>> PostCriteriaMasterTb(CriteriaMasterTb criteriaMasterTb)
        {
            _context.CriteriaMasterTbs.Add(criteriaMasterTb);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetCriteriaMasterTb", new { id = criteriaMasterTb.CriteriaId }, criteriaMasterTb);
        }

        // DELETE: api/Criteria/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCriteriaMasterTb(int id)
        {
            var criteriaMasterTb = await _context.CriteriaMasterTbs.FindAsync(id);
            if (criteriaMasterTb == null)
            {
                return NotFound();
            }

            _context.CriteriaMasterTbs.Remove(criteriaMasterTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }
      */
        private bool CriteriaMasterTbExists(int id)
        {
            return _context.CriteriaMasterTbs.Any(e => e.CriteriaId == id);
        }
    }
}
