﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;
using campusPlacementAPI.DamiModels;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using NuGet.Protocol;
using Microsoft.IdentityModel.Tokens;
using static campusPlacementAPI.Controllers.TokenManager;
namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CompanyOffersController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public CompanyOffersController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/CompanyOffers
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CompanyOffersTb>>> GetCompanyOffersTbs()
        {

            return await _context.CompanyOffersTbs.ToListAsync();
        }
        // GET: api/CompanyOffers
        [HttpGet("ppt")]
        public async Task<IEnumerable< object>> GetCompanies()
        {

            var temp = (from offer in _context.CompanyOffersTbs
                        join cmp in _context.CompanyMasterTbs
                                     on offer.CompanyId equals cmp.CompanyId
                        group new
                        {
                            offer.CompanyId,
                            cmp.Name,
                            offer.MaxCtc,
                            offer.MinCtc
                        } by new { offer.CompanyId, cmp.Name } into g

                        select new
                        {
                            CompanyId = g.Key.CompanyId,
                            CompanyName = g.Key.Name,
                            MinCTC = g.Min(x => x.MinCtc),
                            MaxCTC = g.Max(x => x.MaxCtc)
                        });

           
                return temp;
            
            
        }


        // GET: api/CompanyOffers/5
        [HttpGet("{cid}")]
        public object GetCompanyOffersTb(int cid)
        {
            Request.Headers.TryGetValue("Authorization", out var token);
            if (!token.IsNullOrEmpty())
            {
                if (cid == Convert.ToInt64(ValidateToken(token)))
                {
                    var companyOffersTb = _context.CompanyOffersTbs.Where(x => x.CompanyId == cid).ToList();

                    if (companyOffersTb == null)
                    {
                        return new JsonResult(new { error = "notFound" });
                    }else
                    {
                        return companyOffersTb;
                    }
                }
                else
                {
                    return new JsonResult(new { error = "tokenExpired" });
                }
            }
            else
            {
                return new JsonResult(new { error = "noToken" });
            }
        }

        // PUT: api/CompanyOffers/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCompanyOffersTb(int id, CompanyOffersTb companyOffersTb)
        {
            if (id != companyOffersTb.OfferId)
            {
                return BadRequest();
            }

            _context.Entry(companyOffersTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CompanyOffersTbExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/CompanyOffers
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<object>> PostCompanyOffersTb(CompanyOffer input)
        {
            CompanyOffersTb companyOffersTb = new CompanyOffersTb{
                CompanyId = input.CompanyId,
                NoOfPositions = input.NoOfPositions,
                IsDisclose = input.IsDisclose,
                JobDescription = input.JobDescription,
                MaxCtc = input.MaxCtc,
                MinCtc = input.MinCtc,
                Position = input.Position,
                Technology = input.Technology
            };
            _context.CompanyOffersTbs.Add(companyOffersTb);
            await _context.SaveChangesAsync();
            var temp = _context.CompanyOffersTbs.Where(x => x.CompanyId == input.CompanyId && x.NoOfPositions == input.NoOfPositions && x.JobDescription == input.JobDescription && x.Position == input.Position && x.IsDisclose == input.IsDisclose).FirstOrDefault();
          

            for(var i =0; i < input.Criterias.Length ; i++)
            {
                OfferCriteriaTb offerCriteria = new OfferCriteriaTb
                {
                    CompanyId = input.CompanyId,
                    Criterias = input.Criterias[i].ToString(),
                    OfferId = temp.OfferId,
                    OfferCriteriaId = null

                };
                _context.OfferCriteriaTbs.Add(offerCriteria);
                await _context.SaveChangesAsync();
            }
            
           

            return StatusCode(200);
        }

        // DELETE: api/CompanyOffers/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCompanyOffersTb(int id)
        {
            var companyOffersTb = await _context.CompanyOffersTbs.FindAsync(id);
            if (companyOffersTb == null)
            {
                return NotFound();
            }

            _context.CompanyOffersTbs.Remove(companyOffersTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool CompanyOffersTbExists(int id)
        {
            return _context.CompanyOffersTbs.Any(e => e.OfferId == id);
        }
    }

    internal record NewRecord(object Success, bool Item);
}
