﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DepartmentController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public DepartmentController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/Department
        [HttpGet]
        public async Task<ActionResult<IEnumerable<DepartmentMasterTb>>> GetDepartmentMasterTbs()
        {
            return await _context.DepartmentMasterTbs.Where(e=>e.IsActive==true).ToListAsync();
        }

        // GET: api/Department/5
        [HttpGet("{id}")]
        public async Task<ActionResult<DepartmentMasterTb>> GetDepartmentMasterTb(int id)
        {
            var departmentMasterTb = await _context.DepartmentMasterTbs.FindAsync(id);

            if (departmentMasterTb == null)
            {
                return NotFound();
            }
            else if (departmentMasterTb.IsActive == true)
            {
                return departmentMasterTb;
            }else
            {
                return NotFound();
            }
            
        }

        // PUT: api/Department
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut()]
        public async Task<IActionResult> PutDepartmentMasterTb(DepartmentMasterTb departmentMasterTb)
        {
           

            _context.Entry(departmentMasterTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DepartmentMasterTbExists(departmentMasterTb.DepartmentId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Department
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<DepartmentMasterTb>> PostDepartmentMasterTb(DepartmentMasterTb departmentMasterTb)
        {
            _context.DepartmentMasterTbs.Add(departmentMasterTb);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetDepartmentMasterTb", new { id = departmentMasterTb.DepartmentId }, departmentMasterTb);
        }

        // DELETE: api/Department/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDepartmentMasterTb(int id)
        {
            var departmentMasterTb = await _context.DepartmentMasterTbs.FindAsync(id);
            if (departmentMasterTb == null)
            {
                return NotFound();
            }

            departmentMasterTb.IsActive = false;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DepartmentMasterTbExists(int id)
        {
            return _context.DepartmentMasterTbs.Any(e => e.DepartmentId == id);
        }
    }
}
