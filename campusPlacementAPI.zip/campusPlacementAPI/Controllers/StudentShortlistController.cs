﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentShortlistController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public StudentShortlistController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/StudentShortlist
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StudentShortlistTb>>> GetStudentShortlistTbs()
        {
            return await _context.StudentShortlistTbs.ToListAsync();
        }

        // GET: api/StudentShortlist/5
        [HttpGet("{id}")]
        public async Task<ActionResult<StudentShortlistTb>> GetStudentShortlistTb(int id)
        {
            var studentShortlistTb = await _context.StudentShortlistTbs.FindAsync(id);

            if (studentShortlistTb == null)
            {
                return NotFound();
            }

            return studentShortlistTb;
        }

        // PUT: api/StudentShortlist/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutStudentShortlistTb(int id, StudentShortlistTb studentShortlistTb)
        {
            if (id != studentShortlistTb.ShortlisId)
            {
                return BadRequest();
            }

            _context.Entry(studentShortlistTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentShortlistTbExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/StudentShortlist
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<StudentShortlistTb>> PostStudentShortlistTb(StudentShortlistTb studentShortlistTb)
        {
            _context.StudentShortlistTbs.Add(studentShortlistTb);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetStudentShortlistTb", new { id = studentShortlistTb.ShortlisId }, studentShortlistTb);
        }

        // DELETE: api/StudentShortlist/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudentShortlistTb(int id)
        {
            var studentShortlistTb = await _context.StudentShortlistTbs.FindAsync(id);
            if (studentShortlistTb == null)
            {
                return NotFound();
            }

            _context.StudentShortlistTbs.Remove(studentShortlistTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool StudentShortlistTbExists(int id)
        {
            return _context.StudentShortlistTbs.Any(e => e.ShortlisId == id);
        }
    }
}
