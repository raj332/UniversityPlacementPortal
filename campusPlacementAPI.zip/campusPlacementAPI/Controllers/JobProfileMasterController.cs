﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;
using Microsoft.IdentityModel.Tokens;
using static campusPlacementAPI.Controllers.TokenManager;
namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobProfileMasterController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public JobProfileMasterController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/JobProfileMaster
        [HttpGet]
        public async Task<ActionResult<IEnumerable<JobProfileMasterTb>>> GetJobProfileMasterTbs()
        {
            return await _context.JobProfileMasterTbs.ToListAsync();
        }

        // GET: api/JobProfileMaster/5
        [HttpGet("{id}")]
        public async Task<ActionResult<JobProfileMasterTb>> GetJobProfileMasterTb(long id)
        {
            var jobProfileMasterTb =  _context.JobProfileMasterTbs.Where(x=>x.Spid ==id).FirstOrDefault();

            if (jobProfileMasterTb == null)
            {
                return NotFound();
            }

            return jobProfileMasterTb;
        }

        // PUT: api/JobProfileMaster/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutJobProfileMasterTb(int id, JobProfileMasterTb jobProfileMasterTb)
        {
            if (id != jobProfileMasterTb.JobProfileId)
            {
                return BadRequest();
            }

            _context.Entry(jobProfileMasterTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!JobProfileMasterTbExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/JobProfileMaster
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<JobProfileMasterTb>> PostJobProfileMasterTb(JobProfileMasterTb jobProfileMasterTb)
        {
            Request.Headers.TryGetValue("Authorization", out var token);
            if (!token.IsNullOrEmpty())
            {
                if (jobProfileMasterTb.Spid == Convert.ToInt64(ValidateToken(token)))
                {
                    var oldJob = (_context.JobProfileMasterTbs.Where(x=>x.Spid==jobProfileMasterTb.Spid)).FirstOrDefault();

                    if (oldJob!= null)
                    {
                        _context.JobProfileMasterTbs.Remove(oldJob);
                        await _context.SaveChangesAsync();
                    }
                    _context.JobProfileMasterTbs.Add(jobProfileMasterTb);
                    await _context.SaveChangesAsync();

                    return CreatedAtAction("GetJobProfileMasterTb", new { id = jobProfileMasterTb.JobProfileId }, jobProfileMasterTb);
                }
                else
                {
                    return new JsonResult(new { error = "tokenExpired" });
                }

            }
            else
            {
                return new JsonResult(new { error = "noToken" });
            }
          
        }

        // DELETE: api/JobProfileMaster/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteJobProfileMasterTb(int id)
        {
            var jobProfileMasterTb = await _context.JobProfileMasterTbs.FindAsync(id);
            if (jobProfileMasterTb == null)
            {
                return NotFound();
            }

            _context.JobProfileMasterTbs.Remove(jobProfileMasterTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool JobProfileMasterTbExists(int id)
        {
            return _context.JobProfileMasterTbs.Any(e => e.JobProfileId == id);
        }
    }
}
