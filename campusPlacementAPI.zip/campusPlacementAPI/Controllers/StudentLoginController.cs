﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;
using System.Security.Cryptography.Xml;
using Microsoft.EntityFrameworkCore.Diagnostics;
using campusPlacementAPI.DamiModels;
using Newtonsoft.Json;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentLoginController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public StudentLoginController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/StudentLogin
        /*  [HttpGet]
          public async Task<ActionResult<IEnumerable<StudentLoginMasterTb>>> GetStudentLoginMasterTbs()
          {
              return await _context.StudentLoginMasterTbs.ToListAsync();
          }

          // GET: api/StudentLogin/5
          [HttpGet("{id}")]
          public async Task<ActionResult<StudentLoginMasterTb>> GetStudentLoginMasterTb(long id)
          {
              var studentLoginMasterTb = await _context.StudentLoginMasterTbs.FindAsync(id);

              if (studentLoginMasterTb == null)
              {
                  return NotFound();
              }

              return studentLoginMasterTb;
          }

          // PUT: api/StudentLogin/5
          // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
          [HttpPut("{id}")]
          public async Task<IActionResult> PutStudentLoginMasterTb(long id, StudentLoginMasterTb studentLoginMasterTb)
          {
              if (id != studentLoginMasterTb.Spid)
              {
                  return BadRequest();
              }

              _context.Entry(studentLoginMasterTb).State = EntityState.Modified;

              try
              {
                  await _context.SaveChangesAsync();
              }
              catch (DbUpdateConcurrencyException)
              {
                  if (!StudentLoginMasterTbExists(id))
                  {
                      return NotFound();
                  }
                  else
                  {
                      throw;
                  }
              }

              return NoContent();
          }*/

        // POST: api/StudentLogin
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public JsonResult PostStudentLoginMasterTb(StudentLoginMasterTb studentLoginMasterTb)
        {

            try
            {
                if (StudentLoginMasterTbExists(studentLoginMasterTb.Spid, studentLoginMasterTb.Password))
                {

                    var user = (from stu in _context.StudentMasterTbs join d in _context.PhotoMasterTbs on stu.Spid equals d.Spid where stu.Spid == studentLoginMasterTb.Spid select new { stu.Spid, stu.IsInPlacementDrive,stu.StudentName, d.Photo }).FirstOrDefault();
                    return new JsonResult(new { user ,token = TokenManager.GenerateToken(studentLoginMasterTb.Spid.ToString()) });
                }
                else
                {
                    return new JsonResult(new { error = "Wrong Spid Or Password" });

                }

            }
            catch (DbUpdateException e)
            {
                return new JsonResult(new { error = "Technical Error Try again Later" });
            }

        }
        /*
                // DELETE: api/StudentLogin/5
                [HttpDelete("{id}")]
                public async Task<IActionResult> DeleteStudentLoginMasterTb(long id)
                {
                    var studentLoginMasterTb = await _context.StudentLoginMasterTbs.FindAsync(id);
                    if (studentLoginMasterTb == null)
                    {
                        return NotFound();
                    }

                    _context.StudentLoginMasterTbs.Remove(studentLoginMasterTb);
                    await _context.SaveChangesAsync();

                    return NoContent();
                }
        */
        private bool StudentLoginMasterTbExists(long id,string password)
        {
            return _context.StudentLoginMasterTbs.Any(e => e.Spid== id && e.Password == password);
        }
    }
}
