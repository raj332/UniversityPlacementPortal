﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;
using Microsoft.CodeAnalysis.FlowAnalysis;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CommiteeMemberController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public CommiteeMemberController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/CommiteeMember
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CommiteeMemberMasterTb>>> GetCommiteeMemberMasterTbs()
        {
            return await _context.CommiteeMemberMasterTbs.ToListAsync();
        }

        
        // POST: api/CommiteeMember
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Route("Login")]
        public async Task<ActionResult<object>> PostCommiteeMemberMasterTb(CommiteeMemberMasterTb member)
        {
            try
            {
                
                if (CommiteeMemberMasterTbExists((long)member.Spid, member.Password))
                {

                    var tmp = (from mem in _context.CommiteeMemberMasterTbs where mem.Spid == member.Spid select mem).FirstOrDefault();
                    return new JsonResult(new {user =tmp , token = TokenManager.GenerateToken(tmp.Spid.ToString()) });
                }
                else
                {
                    return new JsonResult(new { error ="Wrong SPID or Password !"});
                    
                }

            }
            catch (DbUpdateException e)
            {
                return new JsonResult(new { error = "Technical Issue , Please try again later !"+ e});

            }
            /* _context.CommiteeMemberMasterTbs.Add(commiteeMemberMasterTb);
             try
             {
                 await _context.SaveChangesAsync();
             }
             catch (DbUpdateException)
             {
                 if (CommiteeMemberMasterTbExists(commiteeMemberMasterTb.CommiteeMemberId))
                 {
                     return Conflict();
                 }
                 else
                 {
                     throw;
                 }
             }

             return CreatedAtAction("GetCommiteeMemberMasterTb", new { id = commiteeMemberMasterTb.CommiteeMemberId }, commiteeMemberMasterTb);*/
        }
        [HttpPost]
        [Route("register")]
        public async Task<ActionResult<object>> RegisterCommiteeMemberMasterTb(CommiteeMemberMasterTb member)
        {
            var check = _context.CommiteeMemberMasterTbs.Where(x => x.Spid == member.Spid).FirstOrDefault();
            if (check == null)
            {
                _context.CommiteeMemberMasterTbs.Add(member);
                await _context.SaveChangesAsync();
                return new JsonResult(new { success = true });
            }
            else
            {
                return new JsonResult(new { error=" Spid is already registered !" });
            }
           

        }
        // DELETE: api/CommiteeMember/5
        /*[HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCommiteeMemberMasterTb(int id)
        {
            var commiteeMemberMasterTb = await _context.CommiteeMemberMasterTbs.FindAsync(id);
            if (commiteeMemberMasterTb == null)
            {
                return NotFound();
            }

            _context.CommiteeMemberMasterTbs.Remove(commiteeMemberMasterTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }
        */
        private bool CommiteeMemberMasterTbExists(long spi ,string password)
        {
            return _context.CommiteeMemberMasterTbs.Any(e => e.Spid ==spi && e.Password ==password);
        }
    }
}
