﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrePlacementTalkController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public PrePlacementTalkController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/PrePlacementTalk
        [HttpGet]
        public async Task<ActionResult<IEnumerable<PrePlacementTalkListTb>>> GetPrePlacementTalkListTbs()
        {

            return await _context.PrePlacementTalkListTbs.ToListAsync();
        }
        // GET: api/PrePlacementTalk
        [HttpGet("votinglist")]
        public async Task<ActionResult<IEnumerable<PrePlacementTalkListTb>>> GetVotingListTbs()
        {
            return await _context.PrePlacementTalkListTbs.Where(x=>x.IsInVotingList==true) .ToListAsync();
        }
        [HttpGet("sheduledlist")]
        public async Task<ActionResult<IEnumerable<PrePlacementTalkListTb>>> GetSheduledListTbs()
        {
            return await _context.PrePlacementTalkListTbs.Where(x => x.IsInSheduleList == true).ToListAsync();
        }
        
        // GET: api/PrePlacementTalk/5
        [HttpGet("{spid}")]
        public async Task<ActionResult<List<PrePlacementTalkListTb>>> GetCompanyForstudent(long? spid)
        {
            var notinclude = (from a in _context.PrePlacementTalkListTbs
                                          join b in _context.CompanyVotingTbs on a.CompanyId equals b.CompanyId
                                          where b.Spid == spid 
                                          select new
                                          {
                                              companyID = a.CompanyId,
                                              companyName = a.CompanyName,
                                              date = a.Date,
                                              venue = a.Venue,
                                              votingEndDate =a.VotingEndDate,
                                              minCtc = a.MinCtc,
                                              maxCtc = a.MaxCtc
                                          }).ToList();
            var mainlist = _context.PrePlacementTalkListTbs.ToList();
            var finalList = mainlist.ExceptBy( notinclude.Select(y => y.companyID), company => company.CompanyId).ToList();


            if (finalList == null)
            {
                return NotFound();
            }

            return finalList;
        }
        
        // PUT: api/PrePlacementTalk/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut]
        public async Task<IActionResult> PutPrePlacementTalkListTb(PrePlacementTalkListTb prePlacementTalkListTb)
        {
          

            _context.Entry(prePlacementTalkListTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!PrePlacementTalkListTbExists(prePlacementTalkListTb.Talkid))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/PrePlacementTalk
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<PrePlacementTalkListTb>> PostPrePlacementTalkListTb(PrePlacementTalkListTb prePlacementTalkListTb)
        {
            _context.PrePlacementTalkListTbs.Add(prePlacementTalkListTb);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetPrePlacementTalkListTb", new { id = prePlacementTalkListTb.Talkid }, prePlacementTalkListTb);
        }
        [HttpPut("vote/{spid}")]
        public async Task<ActionResult<PrePlacementTalkListTb>> DoVote(long spid ,PrePlacementTalkListTb prePlacementTalkListTb)
        {
            CompanyVotingTb input = new CompanyVotingTb {  CompanyId = prePlacementTalkListTb.CompanyId, Spid = spid };
            _context.CompanyVotingTbs.Add(input);
            PrePlacementTalkListTb cmp = _context.PrePlacementTalkListTbs.Where(x => x.Talkid == prePlacementTalkListTb.Talkid).FirstOrDefault();
            cmp.IntrestedStudents = cmp.IntrestedStudents + 1;
            await _context.SaveChangesAsync();

            return StatusCode(200);
        }

        // DELETE: api/PrePlacementTalk/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePrePlacementTalkListTb(int? id)
        {
            var prePlacementTalkListTb = await _context.PrePlacementTalkListTbs.FindAsync(id);
            if (prePlacementTalkListTb == null)
            {
                return NotFound();
            }

            _context.PrePlacementTalkListTbs.Remove(prePlacementTalkListTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool PrePlacementTalkListTbExists(int? id)
        {
            return _context.PrePlacementTalkListTbs.Any(e => e.Talkid == id);
        }
    }
}
