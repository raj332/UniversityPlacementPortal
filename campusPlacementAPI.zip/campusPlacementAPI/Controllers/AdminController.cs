﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;
using campusPlacementAPI.DamiModels;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public AdminController(CampusManagementDBContext context)
        {
            _context = context;
        }
        /*
        // GET: api/Admin
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AdminMasterTb>>> GetAdminMasterTbs()
        {
            return await _context.AdminMasterTbs.Where(e=>e.IsActive==true).ToListAsync();
        }
        */
        // GET: api/Admin/5
        [HttpGet("{id}")]
        public async Task<ActionResult<AdminMasterTb>> GetAdminMasterTb(int id)
        {
            var AdminMasterTb = await _context.AdminMasterTbs.FindAsync(id);
            

            if (AdminMasterTb == null || AdminMasterTb.IsActive == false)
            {
                return NotFound();
            }

            return AdminMasterTb;
        }

        // PUT: api/Admin
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut]
        public async Task<IActionResult> PutAdminMasterTb(AdminMasterTb AdminMasterTb)
        {
          

            _context.Entry(AdminMasterTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!AdminMasterTbExists((int)AdminMasterTb.AdminId))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Admin
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<AdminMasterTb>> PostAdminMasterTb(AdminMasterTb AdminMasterTb)
        {
            _context.AdminMasterTbs.Add(AdminMasterTb);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetAdminMasterTb", new { id = AdminMasterTb.AdminId }, AdminMasterTb);
        }
        // POST: api/Admin/Login
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Route("login")]
        public async Task<ActionResult<AdminMasterTb>> PostAdminMasterTbLogin(Login input)
        {
            
            
            var faculty = _context.AdminMasterTbs.Where(e=>e.AdminEmail==input.email && e.AdminPassword == input.password && e.IsActive == true).SingleOrDefault();
            if (faculty == null)
            {
                return new JsonResult(new { error = "Invailid credentials !" });
            }
            else
            {
                return new JsonResult(new { success = true, adminName = faculty.AdminName , token = TokenManager.GenerateToken(faculty.AdminEmail.ToString()) });
            }
            
        }
        // DELETE: api/Admin/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAdminMasterTb(int id)
        {
            var AdminMasterTb = await _context.AdminMasterTbs.FindAsync(id);
            if (AdminMasterTb == null)
            {
                return NotFound();
            }

            AdminMasterTb.IsActive = false;
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool AdminMasterTbExists(int id)
        {
            return _context.AdminMasterTbs.Any(e => e.AdminId == id);
        }
    }
}
