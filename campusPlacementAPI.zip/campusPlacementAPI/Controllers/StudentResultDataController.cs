﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentResultDataController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public StudentResultDataController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/StudentResultData
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StudentResultDataTb>>> GetStudentResultDataTbs()
        {
            return await _context.StudentResultDataTbs.ToListAsync();
        }

        // GET: api/StudentResultData/5
        [HttpGet("{id}")]
        public async Task<ActionResult<StudentResultDataTb>> GetStudentResultDataTb(long id)
        {
            var studentResultDataTb = await _context.StudentResultDataTbs.FindAsync(id);

            if (studentResultDataTb == null)
            {
                return NotFound();
            }

            return studentResultDataTb;
        }

        // PUT: api/StudentResultData/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
       /* public async Task<IActionResult> PutStudentResultDataTb(long id, StudentResultDataTb studentResultDataTb)
        {
            if (id != studentResultDataTb.Spid)
            {
                return BadRequest();
            }

            _context.Entry(studentResultDataTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentResultDataTbExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/StudentResultData
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<StudentResultDataTb>> PostStudentResultDataTb(StudentResultDataTb studentResultDataTb)
        {
            _context.StudentResultDataTbs.Add(studentResultDataTb);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetStudentResultDataTb", new { id = studentResultDataTb.Spid }, studentResultDataTb);
        }

        // DELETE: api/StudentResultData/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudentResultDataTb(long id)
        {
            var studentResultDataTb = await _context.StudentResultDataTbs.FindAsync(id);
            if (studentResultDataTb == null)
            {
                return NotFound();
            }

            _context.StudentResultDataTbs.Remove(studentResultDataTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    */   
        private bool StudentResultDataTbExists(long id)
        {
            return _context.StudentResultDataTbs.Any(e => e.Spid == id);
        }
    }
}
