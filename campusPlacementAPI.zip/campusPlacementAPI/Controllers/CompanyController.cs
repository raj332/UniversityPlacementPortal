﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;
using campusPlacementAPI.DamiModels;
using System.Data.Common;
using Microsoft.IdentityModel.Tokens;
using static campusPlacementAPI.Controllers.TokenManager;
namespace campusPlacementAPI.Controllers;

[Route("api/[controller]")]
[ApiController]
public class CompanyController : ControllerBase
{
    private readonly CampusManagementDBContext _context;

    public CompanyController(CampusManagementDBContext context)
    {
        _context = context;
    }

    // GET: api/Company
    [HttpGet]
    public async Task<ActionResult<IEnumerable<CompanyMasterTb>>> GetCompanyMasterTbs()
    {
        return await _context.CompanyMasterTbs.ToListAsync();
    }

    // GET: api/Company/5
    [HttpGet("{id}")]
    public async Task<ActionResult<object>> GetCompanyMasterTb(int id)
    {
        var companyMasterTb = await _context.CompanyMasterTbs.FindAsync(id);

        if (companyMasterTb == null)
        {
            return new JsonResult(new {error="No data found !" });  
        }

        return companyMasterTb;
    }
    // GET: api/Company/5
    [HttpGet("authenticate/{id}")]
    public async Task<ActionResult<object>> AuthCompanyMasterTb(int id)
    {
        Request.Headers.TryGetValue("Authorization", out var token);
        if (!token.IsNullOrEmpty())
        {
            if (id == Convert.ToInt64(ValidateToken(token)))
            {
                return new JsonResult(new { sucess = true });

            }
            else
            {
                return new JsonResult(new { error = "tokenExpired" });
            }

        }
        else
        {
            return new JsonResult(new { error = "noToken" });
        }
    }
        [HttpPost]
    [Route("login")]
    public async Task<ActionResult<object>> PostCompanyMasterTb(Login input)
    {
        try
        {
            CompanyMasterTb user = _context.CompanyMasterTbs.Where(x => x.Email == input.email && x.Password == input.password).FirstOrDefault();
            if (user == null)
            {
                return new JsonResult(new { error = "Wrong Email Or Password" });
            }
            else
            {
                return new JsonResult(new { user , token = TokenManager.GenerateToken(user.CompanyId.ToString()) });
            }
        }
        catch (Exception e)
        {
            return new JsonResult(new { error = "Technical issue Try again later!"});
        }
        
   
    }
    // PUT: api/Company/5
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPut]
    public async Task<IActionResult> PutCompanyMasterTb( CompanyMasterTb companyMasterTb)
    {
        
        _context.Entry(companyMasterTb).State = EntityState.Modified;

        try
        {
            await _context.SaveChangesAsync();
            return new JsonResult(new { success = true });

        }
        catch (DbUpdateConcurrencyException e)
        {
            if (!CompanyMasterTbExists((int)companyMasterTb.CompanyId))
            {
                return new JsonResult(new { error = "No data found !" });
            }
            else
            {
                return new JsonResult(new { error = e });
            }
        }

    }

    // POST: api/Company
    // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
    [HttpPost]
    public async Task<ActionResult<object>> PostCompanyMasterTb(CompanyMasterTb companyMasterTb)
    {
        try
        {
            if (_context.CompanyMasterTbs.Any(e => e.Email ==  companyMasterTb.Email || e.ContactNo == companyMasterTb.ContactNo))
            {
                return new JsonResult(new { error = "Email or Contact No is already registered !!"});
            }
            _context.CompanyMasterTbs.Add(companyMasterTb);
            await _context.SaveChangesAsync();
            return CreatedAtAction("GetCompanyMasterTb", new { id = companyMasterTb.CompanyId }, companyMasterTb);

        }
        catch (DbException e)
        {
            return new JsonResult(new { error = " Technical Error :"+e });
        }
       

    }
/*
    // DELETE: api/Company/5
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCompanyMasterTb(int id)
    {
        var companyMasterTb = await _context.CompanyMasterTbs.FindAsync(id);
        if (companyMasterTb == null)
        {
            return NotFound();
        }

        _context.CompanyMasterTbs.Remove(companyMasterTb);
        await _context.SaveChangesAsync();

        return NoContent();
    }
*/
    private bool CompanyMasterTbExists(int id)
    {
        return _context.CompanyMasterTbs.Any(e => e.CompanyId == id);
    }
}
