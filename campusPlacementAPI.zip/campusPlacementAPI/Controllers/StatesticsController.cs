﻿using campusPlacementAPI.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StatesticsController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;
       
        public StatesticsController (CampusManagementDBContext context)
        {
            _context = context;
        }
      

        // GET api/<statasticsController>/5
        [HttpGet("yearlyPlaced/{id}")]
        public object GetPlacedStudentChartData(int id)
        {
            var data = from p in _context.PlacedStudentTbs
                       where p.CompanyId == id
                       group p by p.Year into g
                       select new
                       {
                           Year = g.Key,
                           Count = g.Count()
                       };
        
            return data;
        }

        [HttpGet("yearlyplacement")]
        public object AGetYearlyPlacedStudentChartData()
        {
            var data = from p in _context.PlacedStudentTbs
                       group p by p.Year into g
                       select new
                       {
                           Year = g.Key,
                           Count = g.Count()
                       };

            return data;
        }
        [HttpGet("totalplacedtillnow")]
        public object totalplaced()
        {
            var data = _context.PlacedStudentTbs.Count();

            return data;
        }
        [HttpGet("totalplacedthisyear")]
        public object totalplacedthisyear()
        {
            var data = _context.PlacedStudentTbs.Where(x=>x.Year == DateTime.Now.Year.ToString()).Count();

            return data;
        }
        [HttpGet("currentYearApplication/{id}")]
        public object GetApplicationWiseStudentChartData(int id)
        {
            int totalapplications =  _context.StudentApplicationTbs.Count();
            int myApplications = _context.StudentApplicationTbs.Where(x => x.CompanyId == id).Count();
            return new JsonResult (new{total = totalapplications ,myTotal = myApplications });
        }
        [HttpGet("compantWisePlacement")]
        public object CompanyWisePlacementChart()
        {
           var data = from p in _context.PlacedStudentTbs
                       join cmp in _context.CompanyMasterTbs on p.CompanyId equals cmp.CompanyId
                       group p by cmp.Name into g
                       select new { name = g.Key, count = g.Count() };
            return data;
        }
        [HttpGet("totalRegisteredStudentThisyear")]
        public object totalregisteredStudent()
        {
            var data = _context.JobProfileMasterTbs.Count();
            return data;
        }

        [HttpGet("avgctc")]
        public object averageCtc()
        {
            var sum = _context.PlacedStudentTbs.Select(x => x.Ctc).Sum();
            var count = _context.PlacedStudentTbs.Count();
            var avg = sum / count;
            return avg;
        }
        [HttpGet("toptenplacement")]
        public object top10placements()
        {
            var data = (from student in _context.PlacedStudentTbs
                        join s in _context.StudentMasterTbs on student.Spid equals s.Spid
                        join c in _context.CompanyMasterTbs on student.CompanyId equals c.CompanyId
                        orderby student.Ctc descending
                        select new {student.Ctc ,
                        student.Year ,s.StudentName , c.Name} ).Take(5);

            return data;
        }

        // POST api/<statasticsController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }


      
    }
}
