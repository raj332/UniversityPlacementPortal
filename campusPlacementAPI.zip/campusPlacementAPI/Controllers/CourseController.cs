﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;

namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public CourseController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/Course
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CourseMasterTb>>> GetCourseMasterTbs()
        {
            return await _context.CourseMasterTbs.ToListAsync();
        }

        // GET: api/Course/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CourseMasterTb>> GetCourseMasterTb(int id)
        {
            var courseMasterTb = await _context.CourseMasterTbs.FindAsync(id);

            if (courseMasterTb == null)
            {
                return NotFound();
            }

            return courseMasterTb;
        }

      

        
       

        private bool CourseMasterTbExists(int id)
        {
            return _context.CourseMasterTbs.Any(e => e.CourseId == id);
        }
    }
}
