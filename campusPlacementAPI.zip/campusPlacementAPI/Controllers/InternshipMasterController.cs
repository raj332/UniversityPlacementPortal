﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;
using Microsoft.IdentityModel.Tokens;
using static campusPlacementAPI.Controllers.TokenManager;
namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InternshipMasterController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public InternshipMasterController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/InternshipMaster
        [HttpGet]
        public async Task<ActionResult<IEnumerable<InternshipMasterTb>>> GetInternshipMasterTb()
        {
            return await _context.InternshipMasterTb.ToListAsync();
        }

        // GET: api/InternshipMaster/5
        [HttpGet("{id}")]
        public async Task<ActionResult<List<InternshipMasterTb>>> GetInternshipMasterTb(long? id)
        {
            var internshipMasterTb =  _context.InternshipMasterTb.Where(x => x.Spid == id).ToList();

            if (internshipMasterTb == null)
            {
                return NotFound();
            }

            return internshipMasterTb;
        }

        // PUT: api/InternshipMaster/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutInternshipMasterTb(int? id, InternshipMasterTb internshipMasterTb)
        {
            if (id != internshipMasterTb.InternshipId)
            {
                return BadRequest();
            }

            _context.Entry(internshipMasterTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!InternshipMasterTbExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/InternshipMaster
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<InternshipMasterTb>> PostInternshipMasterTb(InternshipMasterTb internshipMasterTb)
        {
            Request.Headers.TryGetValue("Authorization", out var token);
            if (!token.IsNullOrEmpty())
            {
                if (internshipMasterTb.Spid == Convert.ToInt64(ValidateToken(token)))
                {
                    _context.InternshipMasterTb.Add(internshipMasterTb);
                    await _context.SaveChangesAsync();
                    return new JsonResult(new { success = true });
                }
                else
                {
                    return new JsonResult(new { error = "tokenExpired" });
                }

            }
            else
            {
                return new JsonResult(new { error = "noToken" });
            }
        }

        // DELETE: api/InternshipMaster/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInternshipMasterTb(int? id)
        {
            var internshipMasterTb = await _context.InternshipMasterTb.FindAsync(id);
            if (internshipMasterTb == null)
            {
                return NotFound();
            }

            _context.InternshipMasterTb.Remove(internshipMasterTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool InternshipMasterTbExists(int? id)
        {
            return _context.InternshipMasterTb.Any(e => e.InternshipId == id);
        }
    }
}
