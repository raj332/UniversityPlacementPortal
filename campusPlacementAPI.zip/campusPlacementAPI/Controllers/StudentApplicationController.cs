﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using campusPlacementAPI.Models;
using Microsoft.VisualBasic;
using Microsoft.IdentityModel.Tokens;
using static campusPlacementAPI.Controllers.TokenManager;
namespace campusPlacementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentApplicationController : ControllerBase
    {
        private readonly CampusManagementDBContext _context;

        public StudentApplicationController(CampusManagementDBContext context)
        {
            _context = context;
        }

        // GET: api/StudentApplication
        [HttpGet]
        public async Task<ActionResult<IEnumerable<StudentApplicationTb>>> GetStudentApplicationTbs()
        {
            return await _context.StudentApplicationTbs.ToListAsync();
        }

        // GET: api/StudentApplication/5
        [HttpGet("{id}")]
        public async Task<ActionResult<StudentApplicationTb>> GetStudentApplicationTb(long id)
        {
            var studentApplicationTb = await _context.StudentApplicationTbs.FindAsync(id);

            if (studentApplicationTb == null)
            {
                return NotFound();
            }

            return studentApplicationTb;
        }
        [HttpGet("notapplied/{spid}")]
        public async Task<ActionResult<object>> GetCompaniesThatStudentNotApplied(long spid)
        {
            Request.Headers.TryGetValue("Authorization", out var token);
            if (!token.IsNullOrEmpty())
            {
                if (spid == Convert.ToInt64(ValidateToken(token)))
                {
                    var notinclude = (from a in _context.CompanyOffersTbs
                                      join b in _context.StudentApplicationTbs on a.OfferId equals b.OfferId
                                      where b.Spid == spid
                                      select new
                                      {

                                          offerId = a.OfferId,
                                          companyId = a.CompanyId,
                                          position = a.Position,
                                          technology = a.Technology,
                                          jobDescription = a.JobDescription,
                                          noOfPositions = a.NoOfPositions,
                                          minCtc = a.MinCtc,
                                          maxCtc = a.MaxCtc,
                                          isDisclose = a.IsDisclose
                                      }).ToList();
                    var mainlist = (from a in _context.CompanyOffersTbs
                                    join c in _context.CompanyMasterTbs on a.CompanyId equals c.CompanyId
                                    select new
                                    {
                                        offerId = a.OfferId,
                                        companyId = a.CompanyId,
                                        companyName = c.Name,
                                        position = a.Position,
                                        technology = a.Technology,
                                        jobDescription = a.JobDescription,
                                        noOfPositions = a.NoOfPositions,
                                        minCtc = a.MinCtc,
                                        maxCtc = a.MaxCtc,
                                        isDisclose = a.IsDisclose
                                    }).ToList();
                    ;
                    var finalList = mainlist.ExceptBy(notinclude.Select(y => y.offerId), offer => offer.offerId).ToList();
                    if (finalList == null)
                    {
                        return new JsonResult(new { error = "notFound" });
                    }

                    return finalList;
                }
                else
                {
                    return new JsonResult(new { error = "tokenExpired" });
                }

            }
            else
            {
                return new JsonResult(new { error = "noToken" });
            }

           
        }
        [HttpGet("applied/{spid}")]
        public async Task<ActionResult<object>> GetCompaniesThatStudentApplied(long spid)
        {
            Request.Headers.TryGetValue("Authorization", out var token);
            if (!token.IsNullOrEmpty())
            {
                if (spid == Convert.ToInt64(ValidateToken(token)))
                {
                    var finalList = (from a in _context.CompanyOffersTbs
                                     join b in _context.StudentApplicationTbs on a.OfferId equals b.OfferId
                                     join c in _context.CompanyMasterTbs on a.CompanyId equals c.CompanyId
                                     where b.Spid == spid
                                     select new
                                     {
                                         status = b.Status,
                                         companyName = c.Name,
                                         isSelected = b.IsSelected,
                                         isOutsideProcess = b.IsOutSideProcess,
                                         isPlaced = b.IsPlaced,
                                         offerId = a.OfferId,
                                         finalCTC = b.FinalCTC,
                                         applicationId = b.ApplicationId,
                                         stipend = b.Stipend,
                                         trainingMonths = b.TrainingMonths,
                                         companyId = a.CompanyId,
                                         position = a.Position,
                                         technology = a.Technology,
                                         jobDescription = a.JobDescription,
                                         noOfPositions = a.NoOfPositions,
                                         minCtc = a.MinCtc,
                                         maxCtc = a.MaxCtc,
                                         isDisclose = a.IsDisclose
                                     }).ToList();

                    if (finalList == null)
                    {
                        return new JsonResult(new {error ="notFound"});
                    }

                    return finalList;
                }
                else
                {
                    return new JsonResult(new { error = "tokenExpired" });
                }

            }
            else
            {
                return new JsonResult(new { error = "noToken" });
            }

            
        }
        [HttpGet("applications/{cid}")]
        public async Task<ActionResult<object>> GetStudentApplications(long cid)
        {
            var finalList = (from a in _context.StudentMasterTbs
                             join b in _context.StudentApplicationTbs on a.Spid equals b.Spid
                             join c in _context.CompanyOffersTbs on b.OfferId equals c.OfferId
                             join d in _context.CourseMasterTbs on a.CourseId equals d.CourseId

                             where c.CompanyId == cid && b.IsSelected == false && b.IsOutSideProcess == false && b.HasClearedRounds == false
                             select new
                             {
                                  hasClearedRounds =b.HasClearedRounds,
                                 ApplicationId = b.ApplicationId,
                                 offerId = c.OfferId,
                                 spid = b.Spid,
                                 course = d.CourseName,
                                 studentName = a.StudentName,
                                 email = a.Email,
                                 contactNo = a.ContactNo,
                                 position = c.Position,
                                 technology = c.Technology
                             }).ToList();

            if (finalList == null)
            {
                return NotFound();
            }

            return finalList;
        }
        [HttpGet("shortlisted/{cid}")]
        public async Task<ActionResult<object>> GetShortListedStudentApplications(long cid)
        {
            var finalList = (from a in _context.StudentMasterTbs
                             join b in _context.StudentApplicationTbs on a.Spid equals b.Spid
                             join c in _context.CompanyOffersTbs on b.OfferId equals c.OfferId
                             join d in _context.CourseMasterTbs on a.CourseId equals d.CourseId

                             where c.CompanyId == cid && b.IsSelected == false && b.IsOutSideProcess == false && b.HasClearedRounds == true
                             select new
                             {
                                 hasClearedRounds = b.HasClearedRounds,
                                 ApplicationId = b.ApplicationId,
                                 offerId = c.OfferId,
                                 spid = b.Spid,
                                 course = d.CourseName,
                                 studentName = a.StudentName,
                                 email = a.Email,
                                 contactNo = a.ContactNo,
                                 position = c.Position,
                                 technology = c.Technology
                             }).ToList();

            if (finalList == null)
            {
                return NotFound();
            }

            return finalList;
        }
        [HttpGet("selected/{cid}")]
        public async Task<ActionResult<object>> GetSelectedStudentApplications(long cid)
        {
            var finalList = (from a in _context.StudentMasterTbs
                             join b in _context.StudentApplicationTbs on a.Spid equals b.Spid
                             join c in _context.CompanyOffersTbs on b.OfferId equals c.OfferId
                             join d in _context.CourseMasterTbs on a.CourseId equals d.CourseId

                             where c.CompanyId == cid && b.IsSelected == true  && b.HasClearedRounds == true
                             select new
                             {
                                 isPlaced =b.IsPlaced,
                                 hasClearedRounds = b.HasClearedRounds,
                                 ApplicationId = b.ApplicationId,
                                 offerId = c.OfferId,
                                 spid = b.Spid,
                                 course = d.CourseName,
                                 studentName = a.StudentName,
                                 email = a.Email,
                                 finalCTC =b.FinalCTC,
                                 stipend = b.Stipend,
                                 contactNo = a.ContactNo,
                                 position = c.Position,
                                 technology = c.Technology
                             }).ToList();

            if (finalList == null)
            {
                return NotFound();
            }

            return finalList;
        }
        // PUT: api/StudentApplication
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut]
        public async Task<IActionResult> PutStudentApplicationTb(StudentApplicationTb studentApplicationTb)
        {
            

            _context.Entry(studentApplicationTb).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
                _context.StudentApplicationTbs.Where(x =>x.CompanyId==studentApplicationTb.CompanyId && x.Spid == studentApplicationTb.Spid && x.ApplicationId != studentApplicationTb.ApplicationId).ToList().ForEach(x => x.IsOutSideProcess = true ) ;
                await _context.SaveChangesAsync();
                if(studentApplicationTb.IsSelected ==true && studentApplicationTb.IsOutSideProcess==false && studentApplicationTb.IsPlaced == false)
                {
                    _context.StudentApplicationTbs.Where(x => x.Spid == studentApplicationTb.Spid && x.ApplicationId != studentApplicationTb.ApplicationId).ToList().ForEach(x => x.IsOutSideProcess = true);
                    await _context.SaveChangesAsync();
                }
                if (studentApplicationTb.IsPlaced == true && studentApplicationTb.IsOutSideProcess == true)
                {
                    PlacedStudentTb tmp = new PlacedStudentTb()
                    {
                        Spid = (long)studentApplicationTb.Spid,
                        CompanyId = studentApplicationTb.CompanyId,
                        CourseId = _context.StudentMasterTbs.Where(x => x.Spid == studentApplicationTb.Spid).Select(x => x.CourseId).FirstOrDefault(),
                        Year = DateTime.Now.Year.ToString(),
                        Stipend = (long)studentApplicationTb.Stipend,
                        Ctc = (long)studentApplicationTb.FinalCTC,
                        IsOnCampus = true

                    };
                    StudentMasterTb s1 = _context.StudentMasterTbs.Where(x => x.Spid == studentApplicationTb.Spid).FirstOrDefault();
                    s1.IsInPlacementDrive = false;
                    _context.PlacedStudentTbs.Add(tmp);
                    
                    await _context.SaveChangesAsync();

                }else if(studentApplicationTb.IsOutSideProcess == true && studentApplicationTb.Status == "rejected")
                {
                  
                    StudentMasterTb s1 = _context.StudentMasterTbs.Where(x => x.Spid == studentApplicationTb.Spid).FirstOrDefault();
                    s1.IsInPlacementDrive = false;
                    await _context.SaveChangesAsync();
                }
            }
            catch (DbUpdateConcurrencyException e)
            {
                if (!StudentApplicationTbExists(studentApplicationTb.ApplicationId))
                {
                    return new JsonResult(new { error = "Data not found !" });
                }
                else
                {
                    return new JsonResult(new { error = "Technical issue : "+ e});
                }
            }

            return NoContent();
        }

        // POST: api/StudentApplication
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<StudentApplicationTb>> PostStudentApplicationTb(StudentApplicationTb studentApplicationTb)
        {
            _context.StudentApplicationTbs.Add(studentApplicationTb);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetStudentApplicationTb", new { id = studentApplicationTb.ApplicationId }, studentApplicationTb);
        }

        // DELETE: api/StudentApplication/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudentApplicationTb(long id)
        {
            var studentApplicationTb = await _context.StudentApplicationTbs.FindAsync(id);
            if (studentApplicationTb == null)
            {
                return NotFound();
            }
            
            _context.StudentApplicationTbs.Remove(studentApplicationTb);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool StudentApplicationTbExists(long id)
        {
            return _context.StudentApplicationTbs.Any(e => e.ApplicationId == id);
        }
    }
}
