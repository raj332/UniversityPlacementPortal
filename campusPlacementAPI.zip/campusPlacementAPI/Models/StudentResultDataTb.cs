﻿namespace campusPlacementAPI.Models
{
    public class StudentResultDataTb
    {
        public long Spid { get; set; }
        public double? Sem1Cgpa { get; set; }
        public double? Sem2Cgpa { get; set; }
        public double? Sem3Cgpa { get; set; }
        public double? Sem4Cgpa { get; set; }
        public double? Sem5Cgpa { get; set; }
        public double? Sem6Cgpa { get; set; }
        public double? Sem7Cgpa { get; set; }
        public double? Sem8Cgpa { get; set; }
        public double? Sem9Cgpa { get; set; }
        public double? Sgpa { get; set; }
    }
}
