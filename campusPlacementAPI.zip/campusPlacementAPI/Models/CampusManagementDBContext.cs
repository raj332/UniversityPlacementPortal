﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using campusPlacementAPI.DamiModels;
using campusPlacementAPI.Models;

namespace campusPlacementAPI.Models
{
    public partial class CampusManagementDBContext : DbContext
    {
        public CampusManagementDBContext()
        {
        }

        public CampusManagementDBContext(DbContextOptions<CampusManagementDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<CommiteeMemberMasterTb> CommiteeMemberMasterTbs { get; set; } = null!;
        public virtual DbSet<CompanyInterviewSheduleTb> CompanyInterviewSheduleTbs { get; set; } = null!;
        public virtual DbSet<CompanyMasterTb> CompanyMasterTbs { get; set; } = null!;
        public virtual DbSet<CompanyOffersTb> CompanyOffersTbs { get; set; } = null!;
        public virtual DbSet<CompanyStatsTb> CompanyStatsTbs { get; set; } = null!;
        public virtual DbSet<CompanyVotingTb> CompanyVotingTbs { get; set; } = null!;
        public virtual DbSet<CourseMasterTb> CourseMasterTbs { get; set; } = null!;
        public virtual DbSet<CriteriaMasterTb> CriteriaMasterTbs { get; set; } = null!;
        public virtual DbSet<DepartmentMasterTb> DepartmentMasterTbs { get; set; } = null!;
        public virtual DbSet<DocumnetTypeMaster> DocumnetTypeMasters { get; set; } = null!;
        public virtual DbSet<AdminMasterTb> AdminMasterTbs { get; set; } = null!;
        public virtual DbSet<InternshipMasterTb> InternshipMasterTbs { get; set; } = null!;
        public virtual DbSet<JobProfileMasterTb> JobProfileMasterTbs { get; set; } = null!;

        public virtual DbSet<InterviewProcessMasterTb> InterviewProcessMasterTbs { get; set; } = null!;
        public virtual DbSet<NewsEventTb> NewsEventTbs { get; set; } = null!;
        public virtual DbSet<OfferCriteriaTb> OfferCriteriaTbs { get; set; } = null!;
        public virtual DbSet<StudentResultDataTb> StudentResultDataTbs { get; set; } = null!;

        public virtual DbSet<PhotoMasterTb> PhotoMasterTbs { get; set; } = null!;
        public virtual DbSet<PlacedStudentTb> PlacedStudentTbs { get; set; } = null!;
        public virtual DbSet<PlacemnetMasterTb> PlacemnetMasterTbs { get; set; } = null!;
        public virtual DbSet<PrePlacementTalkListTb> PrePlacementTalkListTbs { get; set; } = null!;
        public virtual DbSet<StudentApplicationTb> StudentApplicationTbs { get; set; } = null!;
        public virtual DbSet<StudentDocumnetListTb> StudentDocumnetListTbs { get; set; } = null!;
        public virtual DbSet<StudentLoginMasterTb> StudentLoginMasterTbs { get; set; } = null!;
        public virtual DbSet<StudentMasterTb> StudentMasterTbs { get; set; } = null!;
        public virtual DbSet<StudentShortlistTb> StudentShortlistTbs { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename='C:\\Program Files\\Microsoft SQL Server\\MSSQL10.SQLEXPRESS\\MSSQL\\DATA\\PlacementManagementSystem.mdf';Integrated Security=True;Connect Timeout=30");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CommiteeMemberMasterTb>(entity =>
            {
                entity.HasKey(e => e.CommiteeMemberId);

                entity.ToTable("CommiteeMemberMasterTB");

                entity.Property(e => e.CommiteeMemberId)
                    .HasColumnName("commiteeMemberID");

               
                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasColumnName("password");

                entity.Property(e => e.Spid).HasColumnName("spid");
            });

            modelBuilder.Entity<CompanyInterviewSheduleTb>(entity =>
            {
                entity.HasKey(e => e.SheduleId)
                    .HasName("PK_InterviewSheduleTB");

                entity.ToTable("CompanyInterviewSheduleTB");

                entity.Property(e => e.SheduleId).HasColumnName("sheduleID");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.Date)
                    .HasColumnType("date")
                    .HasColumnName("date");

                entity.Property(e => e.Venue)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("venue");
            });

            modelBuilder.Entity<CompanyMasterTb>(entity =>
            {
                entity.HasKey(e => e.CompanyId);

                entity.ToTable("CompanyMasterTB");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.Address)
                    .HasMaxLength(150)
                    .IsUnicode(false)
                    .HasColumnName("address");

                entity.Property(e => e.ContactNo).HasColumnName("contactNo");

                entity.Property(e => e.Domain)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("domain");

                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .HasColumnName("email");

                entity.Property(e => e.Name)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("name");
                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasColumnName("password");
                entity.Property(e => e.Website).HasColumnName("website");
            });

            modelBuilder.Entity<CompanyOffersTb>(entity =>
            {
                entity.HasKey(e => e.OfferId);

                entity.ToTable("CompanyOffersTB");

                entity.Property(e => e.OfferId).HasColumnName("offerID");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.IsDisclose).HasColumnName("isDisclose");

                entity.Property(e => e.JobDescription)
                  
                    .HasColumnName("jobDescription");

                entity.Property(e => e.MaxCtc).HasColumnName("maxCTC");

                entity.Property(e => e.MinCtc).HasColumnName("minCTC");

                entity.Property(e => e.NoOfPositions).HasColumnName("noOfPositions");

                entity.Property(e => e.Position)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("position");

                entity.Property(e => e.Technology)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("technology");
            });

            modelBuilder.Entity<CompanyStatsTb>(entity =>
            {
                entity.HasKey(e => e.StatasticsId);

                entity.ToTable("CompanyStatsTB");

                entity.Property(e => e.StatasticsId).HasColumnName("statasticsID");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.DriveId).HasColumnName("driveID");
            });

            modelBuilder.Entity<CompanyVotingTb>(entity =>
            {
                entity.HasKey(e => e.VotingId);

                entity.ToTable("CompanyVotingTB");

                entity.Property(e => e.VotingId).HasColumnName("votingID");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.Spid).HasColumnName("spid");
            });

            modelBuilder.Entity<CourseMasterTb>(entity =>
            {
                entity.HasKey(e => e.CourseId);

                entity.ToTable("CourseMasterTB");

                entity.Property(e => e.CourseId).HasColumnName("courseID");

                entity.Property(e => e.CourseName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("courseName");

                entity.Property(e => e.DepartmentId).HasColumnName("departmentID");

                entity.Property(e => e.Intakes).HasColumnName("intakes");
            });

            modelBuilder.Entity<CriteriaMasterTb>(entity =>
            {
                entity.HasKey(e => e.CriteriaId)
                    .HasName("PK_criteriaMasterTB");

                entity.ToTable("CriteriaMasterTB");

                entity.Property(e => e.CriteriaId).HasColumnName("criteriaID");

                entity.Property(e => e.CriteriaName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("criteriaName");
            });

            modelBuilder.Entity<DepartmentMasterTb>(entity =>
            {
                entity.HasKey(e => e.DepartmentId);

                entity.ToTable("DepartmentMasterTB");

                entity.Property(e => e.DepartmentId).HasColumnName("departmentID");

                entity.Property(e => e.ContactNo)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("contactNo");

                entity.Property(e => e.DepartmentEmail)
                    .HasMaxLength(50)
                    .HasColumnName("departmentEmail");

                entity.Property(e => e.DepartmentName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("departmentName");

                entity.Property(e => e.IsActive).HasColumnName("isActive");
            });

            modelBuilder.Entity<DocumnetTypeMaster>(entity =>
            {
                entity.HasKey(e => e.DocumentTypeId);

                entity.ToTable("DocumnetTypeMaster");

                entity.Property(e => e.DocumentTypeId).HasColumnName("documentTypeID");

                entity.Property(e => e.DocumnetName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("documnetName");

                entity.Property(e => e.IsActive).HasColumnName("isActive");
            });

            modelBuilder.Entity<AdminMasterTb>(entity =>
            {
                entity.HasKey(e => e.AdminId);

                entity.ToTable("AdminMasterTB");

                entity.Property(e => e.AdminId).HasColumnName("adminID");


                entity.Property(e => e.AdminEmail)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("adminEmail");

                entity.Property(e => e.AdminName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("adminName");

                entity.Property(e => e.AdminPassword)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("adminPassword");

                entity.Property(e => e.IsActive).HasColumnName("isActive");
            });
            modelBuilder.Entity<InternshipMasterTb>(entity =>
            {
                entity.HasKey(e => e.InternshipId);

                entity.ToTable("InternshipMasterTB");

                entity.Property(e => e.Spid)
                    .HasColumnName("spid");
                entity.Property(e => e.InternshipId)
                   .HasColumnName("internshipId");
                entity.Property(e => e.CompanyName).HasColumnName("companyName");

                entity.Property(e => e.StartDate).HasColumnName("startDate").HasColumnType("date")
;
                entity.Property(e => e.EndDate).HasColumnName("endDate").HasColumnType("date");

                entity.Property(e => e.Technology)
                    .HasColumnName("technology");
            });
            modelBuilder.Entity<InterviewProcessMasterTb>(entity =>
            {
                entity.HasKey(e => e.ProcessId);

                entity.ToTable("InterviewProcessMasterTB");

                entity.Property(e => e.ProcessId).HasColumnName("processID");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.RoundType)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<JobProfileMasterTb>(entity =>
            {
                entity.HasKey(e => e.JobProfileId);

                entity.ToTable("JobProfileMasterTB");

                entity.Property(e => e.Spid).HasColumnName("spid");

                entity.Property(e => e.WebsiteLink).HasColumnName("websiteLink");
                entity.Property(e => e.LinkedinLink).HasColumnName("linkedinLink");

                entity.Property(e => e.ResumeLink).HasColumnName("resumeLink");
            });
            modelBuilder.Entity<NewsEventTb>(entity =>
            {
                entity.HasKey(e => e.NewsId);

                entity.ToTable("NewsEventTB");

                entity.Property(e => e.NewsId).HasColumnName("newsID");

                entity.Property(e => e.Date)
                    .HasColumnType("date")
                    .HasColumnName("date");

                entity.Property(e => e.GeneratedBy).HasColumnName("generatedBy");

                entity.Property(e => e.NewsContent)
                    .IsUnicode(false)
                    .HasColumnName("newsContent");
            });

            modelBuilder.Entity<OfferCriteriaTb>(entity =>
            {
                entity.HasKey(e => e.OfferCriteriaId);

                entity.ToTable("OfferCriteriaTB");

                entity.Property(e => e.OfferCriteriaId).HasColumnName("offerCriteriaID");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.Criterias).HasColumnName("criterias");

                entity.Property(e => e.OfferId).HasColumnName("offerID");
            });

            modelBuilder.Entity<PhotoMasterTb>(entity =>
            {
                entity.HasKey(e => e.PhotoId);

                entity.ToTable("PhotoMasterTB");

                entity.Property(e => e.PhotoId).HasColumnName("photoID");

                entity.Property(e => e.Photo)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("photo");

                entity.Property(e => e.Spid).HasColumnName("spid");
            });

            modelBuilder.Entity<PlacedStudentTb>(entity =>
            {
                entity.HasKey(e => e.PlacedStudentId);

                entity.ToTable("PlacedStudentTB");

                entity.Property(e => e.PlacedStudentId).HasColumnName("placedStudentID");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.CourseId).HasColumnName("courseID");

                entity.Property(e => e.Ctc).HasColumnName("CTC");

                entity.Property(e => e.IsOnCampus).HasColumnName("isOnCampus");

                entity.Property(e => e.Spid).HasColumnName("spid");

                entity.Property(e => e.Stipend).HasColumnName("stipent");

                entity.Property(e => e.Year)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("year");
            });

            modelBuilder.Entity<PlacemnetMasterTb>(entity =>
            {
                entity.HasKey(e => e.DriveId);

                entity.ToTable("PlacemnetMasterTB");

                entity.Property(e => e.DriveId).HasColumnName("driveID");

                entity.Property(e => e.DriveName).HasColumnName("driveName");

                entity.Property(e => e.EndDate)
                    .HasColumnType("date")
                    .HasColumnName("endDate");

                entity.Property(e => e.IsActive).HasColumnName("isActive");

                entity.Property(e => e.StartDate)
                    .HasColumnType("date")
                    .HasColumnName("startDate");
            });

            modelBuilder.Entity<PrePlacementTalkListTb>(entity =>
            {
                entity.HasKey(e => e.Talkid);

                entity.ToTable("PrePlacementTalkLIstTB");

                entity.Property(e => e.Talkid).HasColumnName("talkid");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.Date)
                    .HasColumnType("date")
                    .HasColumnName("date");
                entity.Property(e => e.VotingEndDate)
                  .HasColumnType("date")
                  .HasColumnName("votingEndDate");
                entity.Property(e => e.CompanyName)
                    .HasColumnName("companyName");
                entity.Property(e => e.IsInSheduleList)
                    .HasColumnName("isInSheduledList");
                entity.Property(e => e.IsInVotingList)
                   .HasColumnName("isInVotingList");
                entity.Property(e => e.MinCtc)
                    .HasColumnName("minCtc");
                entity.Property(e => e.MaxCtc)
                   .HasColumnName("maxCtc");
                entity.Property(e => e.IntrestedStudents).HasColumnName("intrestedStudents");

                entity.Property(e => e.IsVisitingCampus).HasColumnName("isVisitingCampus");

                entity.Property(e => e.Venue)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("venue");
            });

            modelBuilder.Entity<StudentApplicationTb>(entity =>
            {
                entity.HasKey(e => e.ApplicationId);

                entity.ToTable("StudentApplicationTB");

                entity.Property(e => e.ApplicationId).HasColumnName("applicationID");

                entity.Property(e => e.OfferId).HasColumnName("offerId");

                entity.Property(e => e.IsOutSideProcess).HasColumnName("isOutSideProcess");

                entity.Property(e => e.IsSelected).HasColumnName("isSelected");

                entity.Property(e => e.Spid).HasColumnName("spid");
                entity.Property(e => e.HasClearedRounds).HasColumnName("hasClearedRounds");
                entity.Property(e => e.IsPlaced).HasColumnName("isPlaced");
                entity.Property(e => e.CompanyId).HasColumnName("companyId");
                entity.Property(e => e.FinalCTC).HasColumnName("finalCTC");
                entity.Property(e => e.Stipend).HasColumnName("stipend");

                entity.Property(e => e.TrainingMonths).HasColumnName("trainingMonths");



                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("status");
            });

            modelBuilder.Entity<StudentDocumnetListTb>(entity =>
            {
                entity.HasKey(e => e.StudentDocId);

                entity.ToTable("StudentDocumnetListTB");

                entity.Property(e => e.StudentDocId).HasColumnName("studentDocID");

                entity.Property(e => e.DocumentLink)
                    .HasMaxLength(50)
                    .HasColumnName("documentLink");

                entity.Property(e => e.DocumentTypeId).HasColumnName("documentTypeID");

                entity.Property(e => e.Spid).HasColumnName("spid");
            });

            modelBuilder.Entity<StudentLoginMasterTb>(entity =>
            {
                entity.HasKey(e => e.Spid);

                entity.ToTable("StudentLoginMasterTB");

                entity.Property(e => e.Spid)
                    .ValueGeneratedNever()
                    .HasColumnName("spid");

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .HasColumnName("password");
            });
            modelBuilder.Entity<StudentResultDataTb>(entity =>
            {
                entity.HasKey(e => e.Spid);

                entity.ToTable("StudentResultDataTB");

                entity.Property(e => e.Spid)
                    .HasColumnName("spid");

                entity.Property(e => e.Sem1Cgpa)
                    .HasColumnName("sem1Cgpa");
                entity.Property(e => e.Sem2Cgpa)
                   .HasColumnName("sem2Cgpa");
                entity.Property(e => e.Sem3Cgpa)
                   .HasColumnName("sem3Cgpa");
                entity.Property(e => e.Sem4Cgpa)
                   .HasColumnName("sem4Cgpa");
                entity.Property(e => e.Sem5Cgpa)
                   .HasColumnName("sem5Cgpa");
                entity.Property(e => e.Sem6Cgpa)
                   .HasColumnName("sem6Cgpa");
                entity.Property(e => e.Sem7Cgpa)
                   .HasColumnName("sem7Cgpa");
                entity.Property(e => e.Sem8Cgpa)
                   .HasColumnName("sem8Cgpa");
                entity.Property(e => e.Sem9Cgpa)
                   .HasColumnName("sem9Cgpa");
                entity.Property(e => e.Sgpa)
                   .HasColumnName("sgpa");

            });
            modelBuilder.Entity<StudentMasterTb>(entity =>
            {
                entity.HasKey(e => e.Spid);

                entity.ToTable("StudentMasterTB");

                entity.Property(e => e.Spid)
                    .ValueGeneratedNever()
                    .HasColumnName("spid");

                entity.Property(e => e.ContactNo).HasColumnName("contactNo");

                entity.Property(e => e.CourseId).HasColumnName("courseId");
                entity.Property(e => e.IsInPlacementDrive).HasColumnName("isInPlacementDrive");


                entity.Property(e => e.Email)
                    .HasMaxLength(50)
                    .HasColumnName("email");


                entity.Property(e => e.StudentName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("studentName");
            });

            modelBuilder.Entity<StudentShortlistTb>(entity =>
            {
                entity.HasKey(e => e.ShortlisId);

                entity.ToTable("StudentShortlistTB");

                entity.Property(e => e.ShortlisId).HasColumnName("shortlisID");

                entity.Property(e => e.ClearedRounds).HasColumnName("clearedRounds");

                entity.Property(e => e.CompanyId).HasColumnName("companyID");

                entity.Property(e => e.IsPlaced).HasColumnName("isPlaced");

                entity.Property(e => e.IsSelectedForInterview).HasColumnName("isSelectedForInterview");

                entity.Property(e => e.Spid).HasColumnName("spid");

                entity.Property(e => e.Status)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("status");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

        public DbSet<campusPlacementAPI.DamiModels.StudentReg> StudentReg { get; set; }

        public DbSet<campusPlacementAPI.Models.InternshipMasterTb> InternshipMasterTb { get; set; }
    }
}
