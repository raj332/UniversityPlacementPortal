﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class StudentMasterTb
    {
        public long Spid { get; set; }
        public string StudentName { get; set; } = null!;
        public int CourseId { get; set; }
        public long ContactNo { get; set; }
        public string Email { get; set; } = null!;

        public Boolean IsInPlacementDrive { get; set; }
    }
}
