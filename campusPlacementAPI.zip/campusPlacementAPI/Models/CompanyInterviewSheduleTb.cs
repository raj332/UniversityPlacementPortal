﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class CompanyInterviewSheduleTb
    {
        public int SheduleId { get; set; }
        public DateTime? Date { get; set; }
        public string? Venue { get; set; }
        public int? CompanyId { get; set; }
    }
}
