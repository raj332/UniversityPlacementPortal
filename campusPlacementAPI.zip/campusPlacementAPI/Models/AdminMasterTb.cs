﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class AdminMasterTb
    {
        public int ? AdminId { get; set; }
        public string AdminName { get; set; } 
        public string AdminEmail { get; set; } = null!;
        public string AdminPassword { get; set; } = null!;
        public bool IsActive { get; set; }
    }
}
