﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class StudentShortlistTb
    {
        public int ShortlisId { get; set; }
        public long? Spid { get; set; }
        public int? CompanyId { get; set; }
        public bool? IsSelectedForInterview { get; set; }
        public int? ClearedRounds { get; set; }
        public bool? IsPlaced { get; set; }
        public string? Status { get; set; }
    }
}
