﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class CompanyStatsTb
    {
        public int StatasticsId { get; set; }
        public int DriveId { get; set; }
        public int CompanyId { get; set; }
    }
}
