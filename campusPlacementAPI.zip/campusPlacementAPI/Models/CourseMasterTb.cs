﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class CourseMasterTb
    {
        public int CourseId { get; set; }
        public string CourseName { get; set; } = null!;
        public long Intakes { get; set; }
        public int DepartmentId { get; set; }
    }
}
