﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class StudentLoginMasterTb
    {
        public long Spid { get; set; }
        public string Password { get; set; } = null!;
    }
}
