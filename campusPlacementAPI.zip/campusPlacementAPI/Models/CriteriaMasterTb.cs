﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class CriteriaMasterTb
    {
        public int CriteriaId { get; set; }
        public string? CriteriaName { get; set; }
    }
}
