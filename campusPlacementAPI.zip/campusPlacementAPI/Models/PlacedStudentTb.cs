﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class PlacedStudentTb
    {
        public int PlacedStudentId { get; set; }
        public long Spid { get; set; }
        public int ? CompanyId { get; set; }
        public int ? CourseId { get; set; }
        public string Year { get; set; } = null!;
        public long Stipend { get; set; }
        public long Ctc { get; set; }
        public bool IsOnCampus { get; set; }
    }
}
