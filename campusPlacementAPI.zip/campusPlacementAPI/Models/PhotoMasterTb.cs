﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class PhotoMasterTb
    {
        public int PhotoId { get; set; }
        public long Spid { get; set; }
        public string Photo { get; set; } = null!;
    }
}
