﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class OfferCriteriaTb
    {
        public int? OfferCriteriaId { get; set; }
        public int? OfferId { get; set; }
        public int? CompanyId { get; set; }
        public string ? Criterias { get; set; }
     
    }
}
