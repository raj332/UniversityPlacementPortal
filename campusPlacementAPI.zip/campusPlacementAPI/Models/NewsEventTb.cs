﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class NewsEventTb
    {
        public int NewsId { get; set; }
        public string NewsContent { get; set; } = null!;
        public int GeneratedBy { get; set; }
        public DateTime Date { get; set; }
    }
}
