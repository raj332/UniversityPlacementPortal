﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class CompanyVotingTb
    {
        public int VotingId { get; set; }
        public int CompanyId { get; set; }
        public long Spid { get; set; }
    }
}
