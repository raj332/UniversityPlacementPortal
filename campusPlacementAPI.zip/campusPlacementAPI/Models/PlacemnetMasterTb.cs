﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class PlacemnetMasterTb
    {
        public int DriveId { get; set; }
        public int DriveName { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public bool IsActive { get; set; }
    }
}
