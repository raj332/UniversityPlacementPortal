﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class CompanyOffersTb
    {
        public int? OfferId { get; set; }
        public int? CompanyId { get; set; }
        public string? Position { get; set; }
        public string? Technology { get; set; }
        public string? JobDescription { get; set; }
        public int? NoOfPositions { get; set; }
        public long MinCtc { get; set; }
        public long MaxCtc { get; set; }
        public bool? IsDisclose { get; set; }
    }
}
