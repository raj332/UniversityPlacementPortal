﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class DocumnetTypeMaster
    {
        public int DocumentTypeId { get; set; }
        public string DocumnetName { get; set; } = null!;
        public bool IsActive { get; set; }
    }
}
