﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class PrePlacementTalkListTb
    {
        public int ? Talkid { get; set; }
        public  int CompanyId { get; set; }
        public string CompanyName { get; set; }
        public bool ? IsInVotingList { get; set; }
         public bool ? IsInSheduleList { get; set; }
        public int ? MaxCtc { get; set; }
         public DateTime ? VotingEndDate { get; set; }
        public int ? MinCtc { get; set; }
        public DateTime ? Date { get; set; }
        public string ? Venue { get; set; } 
        public int ? IntrestedStudents { get; set; }
        public bool ? IsVisitingCampus { get; set; }
    }
}
