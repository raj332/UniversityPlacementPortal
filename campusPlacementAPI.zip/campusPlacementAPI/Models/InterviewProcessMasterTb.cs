﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class InterviewProcessMasterTb
    {
        public int ProcessId { get; set; }
        public int? CompanyId { get; set; }
        public string? RoundType { get; set; }
    }
}
