﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class StudentDocumnetListTb
    {
        public int StudentDocId { get; set; }
        public int? DocumentTypeId { get; set; }
        public string? DocumentLink { get; set; }
        public long? Spid { get; set; }
    }
}
