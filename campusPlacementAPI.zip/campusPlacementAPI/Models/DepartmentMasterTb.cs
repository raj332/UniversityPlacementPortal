﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class DepartmentMasterTb
    {
        public int DepartmentId { get; set; }
        public string? DepartmentName { get; set; }
        public decimal? ContactNo { get; set; }
        public bool IsActive { get; set; }
        public string? DepartmentEmail { get; set; }
    }
}
