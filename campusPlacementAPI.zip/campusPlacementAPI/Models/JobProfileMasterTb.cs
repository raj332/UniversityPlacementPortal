﻿namespace campusPlacementAPI.Models
{
    public class JobProfileMasterTb
    {
        public int JobProfileId { get; set; }
        public long Spid { get; set; }

        public string WebsiteLink { get; set; }
        public string LinkedinLink { get; set; }

        public string ResumeLink { get; set; }


    }
}
