﻿using System;
using System.Collections.Generic;

namespace campusPlacementAPI.Models
{
    public partial class StudentApplicationTb
    {
        public long ApplicationId { get; set; }
        public long? Spid { get; set; }
        public int? OfferId { get; set; }
        public string? Status { get; set; }
        public bool? IsOutSideProcess { get; set; }
        public bool? IsSelected { get; set; }
        public bool? HasClearedRounds { get; set; }
        public long ? FinalCTC { get; set; }
        public int ? Stipend { get; set; }
        public bool? IsPlaced { get; set; }
        public int? CompanyId { get; set; }
        public int ? TrainingMonths { get; set; }

    }
}
