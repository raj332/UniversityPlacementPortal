﻿using System.ComponentModel.Design;

namespace campusPlacementAPI.Models
{
    public class InternshipMasterTb
    {
        public int ? InternshipId { get; set; }
        public long Spid { get; set; }
        public string CompanyName { get; set; }

        public DateTime ? StartDate { get; set; }
        public DateTime ? EndDate { get; set; }

        public string ? Technology { get; set; }


    }
}
